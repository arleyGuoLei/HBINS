# Host: 172.20.109.101  (Version: 5.7.19-0ubuntu0.16.04.1)
# Date: 2018-09-15 09:03:00
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES gb2312 */;

#
# Structure for table "shop_cat"
#

DROP TABLE IF EXISTS `shop_cat`;
CREATE TABLE `shop_cat` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `catname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `catname` (`catname`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

#
# Data for table "shop_cat"
#

INSERT INTO `shop_cat` VALUES (10,'ʳ��'),(11,'���Ӳ�Ʒ'),(12,'�·�');

#
# Structure for table "shop_content"
#

DROP TABLE IF EXISTS `shop_content`;
CREATE TABLE `shop_content` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `cat` int(8) NOT NULL,
  `date` date NOT NULL,
  `picture` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat` (`cat`),
  CONSTRAINT `shop_content_ibfk_1` FOREIGN KEY (`cat`) REFERENCES `shop_cat` (`id`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

#
# Data for table "shop_content"
#

INSERT INTO `shop_content` VALUES (88,'mi8',11,'2018-08-23','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(89,'mi8',11,'2018-08-19','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(90,'mi8',11,'2018-08-15','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(91,'mi8',11,'2018-08-11','static/img/goods/mi8.jpg','static/img/goods/mi8.jpg'),(92,'iphonex',11,'2018-08-12','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(93,'iphonex',11,'2018-08-16','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(94,'iphonex',11,'2018-08-20','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(95,'iphonex',11,'2018-08-24','static/img/goods/iphonex.jpg','static/img/goods/iphonex.jpg'),(96,'t-shirt',12,'2018-08-13','static/img/goods/t-shirt.jpg','static/img/goods/t-shirt.jpg'),(97,'t-shirt',12,'2018-08-17','static/img/goods/t-shirt.jpg','static/img/goods/t-shirt.jpg'),(98,'t-shirt',12,'2018-08-21','static/img/goods/t-shirt.jpg','static/img/goods/t-shirt.jpg'),(99,'cola',10,'2018-08-14','static/img/goods/cola.jpg','static/img/goods/cola.jpg'),(100,'cola',10,'2018-08-18','static/img/goods/cola.jpg','static/img/goods/cola.jpg'),(101,'cola',10,'2018-08-22','static/img/goods/cola.jpg','static/img/goods/cola.jpg');

#
# Structure for table "shop_user"
#

DROP TABLE IF EXISTS `shop_user`;
CREATE TABLE `shop_user` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "shop_user"
#

INSERT INTO `shop_user` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3');
