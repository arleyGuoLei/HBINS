<?php
/* Define app root */
define( 'DS' , DIRECTORY_SEPARATOR );
define( 'WROOT' , dirname( __FILE__ ) . DS  );

/****  load core code  ***/
include_once( 'core'.DS .'init.php' );
