<?php
$file_path = "/flag.txt";
if(file_exists($file_path)){
$fp = fopen($file_path,"r");
$str = fread($fp,filesize($file_path));
echo $str = str_replace("\r\n","<br />",$str);
}
?>
